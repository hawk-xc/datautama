<?php
    // hapus section
    include 'functions.php';
    connection('127.0.0.1', 'popo', 'password', 'MyDB');
    hapus($_GET);
?>