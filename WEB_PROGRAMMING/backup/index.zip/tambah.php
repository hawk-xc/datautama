<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <link rel="stylesheet" href="styling.css" />
    <link rel="preconnect" href="https://fonts.googleapis.com" />
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin />
    <link href="https://fonts.googleapis.com/css2?family=Sora:wght@100;300;600&display=swap" rel="stylesheet" />
    <title>Document</title>
</head>

<body>
    <div class="container">
        <div class="box">
            <form action="" method="POST">
                <input type="text" name="nama" placeholder="nama" style="color: black" autofocus required>
                <input type="submit" name="submit" placeholder="kirim" style="color: black">
            </form>
            <?php
              include 'functions.php';
              connection('127.0.0.1', 'popo', 'password', 'MyDB');
              if ( isset($_POST['submit'])):
                if ( tambah($_POST) > 0 ) {
                    echo "
                        <script>
                        alert('data berhasil ditambah!');
                        document.location.href = 'index.php';
                        </script>
                    ";
                }
                else {
                    echo "
                        <script>
                        alert('data gagal ditambah!');
                        document.location.href = 'index.php';
                        </script>
                    ";
                }
                
              endif;
            ?>
        </div>
    </div>
</body>

</html>